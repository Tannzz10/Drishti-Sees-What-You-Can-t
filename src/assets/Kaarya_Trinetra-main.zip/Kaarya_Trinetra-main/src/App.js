
import Nav from './components/Navbar';
import Intro from './components/intro';

import './App.css';

function App() {
  return (
    <>
    <Nav/>
    <Intro/>
   
    </>
  );
}

export default App;
